# vue-weui

weui for vue(vue + vue-router + weui + es6 + webpack)

## 开发

```
git clone https://github.com/aidenzou/vue-weui.git
cd vue-weui
npm install
npm run dev
```
运行`npm run dev`命令，会监听目录下所有文件的变更，并且默认会在`8080`端口启动服务器，然后在浏览器打开 `http://localhost:8080`。


## Links

- [实例查看](http://aidenzou.github.io/vue-weui/#!/)
- [weui](https://github.com/weui/weui)
- [react-weui](https://github.com/n7best/react-weui)

## QQ群

<a target="_blank" href="http://shang.qq.com/wpa/qunwpa?idkey=c735b2b5e7d83d2043584e78d1c9d0475f6064e82701ec01ed28e7aa163946ea"><img border="0" src="http://pub.idqqimg.com/wpa/images/group.png" alt="vue.js" title="vue.js"></a>
