<template>
  <div class="page msg">
    <Msg></Msg>
  </div>
</template>

<script>
import Msg from './../../src/Msg.vue'

export default {
  name:'MsgView',
  components:{
    Msg
  }
}
</script>
