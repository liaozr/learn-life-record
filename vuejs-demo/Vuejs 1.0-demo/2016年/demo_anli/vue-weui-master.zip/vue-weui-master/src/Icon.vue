<style lang="less">

@import "./style/icon/weui_icon_font";

</style>
