<script>

import Select from './Select.vue'

export default {
    name: 'Cell'
}

</script>
